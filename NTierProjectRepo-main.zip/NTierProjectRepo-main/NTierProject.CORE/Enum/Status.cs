﻿using System;
using System.Collections.Generic;
using System.Text;

namespace NTierProject.CORE.Enum
{
    public enum Status
    {
        None = 0,
        Active = 1,
        Updated = 3,
        Deleted = 5
    }
}
